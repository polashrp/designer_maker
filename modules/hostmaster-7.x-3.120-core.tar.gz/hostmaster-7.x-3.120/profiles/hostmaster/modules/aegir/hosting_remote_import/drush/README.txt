Remote import - Provision
=========================

This Drush extension allows you to fetch remote sites from remote Aegir servers.

Installation
------------

Follow the normal procedure for installing a Drush extension on your system.
Normally, this would mean it should be at /var/aegir/.drush/remote_import.
You do not need to install anything on the server from which sites will be
copied.

See also
--------

You probably want to install the Remote import - Hostmaster project into your
Aegir frontend: https://drupal.org/project/hosting_remote_import
