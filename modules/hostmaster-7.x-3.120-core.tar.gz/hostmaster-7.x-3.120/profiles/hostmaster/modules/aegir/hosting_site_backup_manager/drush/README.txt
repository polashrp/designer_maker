Provision site Backup Manager
======================================

This is the provision code for Hosting site Backup Manager
https://drupal.org/project/hosting_site_backup_manager

INSTALLATION
------------

This code is for provision, so it needs to be uploaded
in the ~/.drush/ directory of your Aegir backend.


