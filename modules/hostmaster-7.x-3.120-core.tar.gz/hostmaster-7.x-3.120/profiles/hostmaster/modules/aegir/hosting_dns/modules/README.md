This folder holds the different hooks that could be implemented by the hosting 
sub-modules. 