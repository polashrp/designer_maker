<?php


class Provision_Config_Dnsmasq_Host extends Provision_Config_Dns_Host {

}
