<?php

class Provision_Config_Dnsmasq_Server extends Provision_Config_Dns_Server {

}
