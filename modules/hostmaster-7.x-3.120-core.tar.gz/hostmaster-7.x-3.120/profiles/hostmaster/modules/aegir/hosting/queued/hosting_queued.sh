#!/bin/bash

$DRUSH_COMMAND @hostmaster hosting-queued
