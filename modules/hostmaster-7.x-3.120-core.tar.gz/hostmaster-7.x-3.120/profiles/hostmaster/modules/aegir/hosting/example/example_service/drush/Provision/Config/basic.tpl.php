This is an example template for the example service in provision.

The value set in the UI for this service was : <?php print $this->example_field; ?>

The time generated in the data_options() method was: <?php print $example_current_time; ?>
